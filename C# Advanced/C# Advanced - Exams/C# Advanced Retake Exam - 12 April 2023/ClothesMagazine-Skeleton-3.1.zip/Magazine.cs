﻿namespace ClothesMagazine
{
    public class Magazine
    {
    }
}
