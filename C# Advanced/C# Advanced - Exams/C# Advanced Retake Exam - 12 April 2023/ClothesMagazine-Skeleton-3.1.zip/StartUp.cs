﻿namespace ClothesMagazine
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
