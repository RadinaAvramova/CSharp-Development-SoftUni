﻿namespace AutomotiveRepairShop
{
    public class Vehicle
    {
    }
}
