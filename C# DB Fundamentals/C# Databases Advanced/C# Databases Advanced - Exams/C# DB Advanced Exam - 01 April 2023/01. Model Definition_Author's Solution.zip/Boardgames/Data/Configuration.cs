﻿namespace Boardgames.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=Boardgames;Integrated Security=True;Encrypt=False";
    }
}
