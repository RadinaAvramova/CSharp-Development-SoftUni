﻿namespace Handball.Utilities.Messages
{
    public class ExceptionMessages
    {
        public const string PlayerNameNull = "Player name cannot be null or empty.";
        public const string TeamNameNull = "Team name cannot be null or empty.";
    }
}
