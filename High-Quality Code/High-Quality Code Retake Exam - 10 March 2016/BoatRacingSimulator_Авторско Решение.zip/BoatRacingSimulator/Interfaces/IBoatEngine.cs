﻿namespace BoatRacingSimulator.Interfaces
{
    public interface IBoatEngine : IModelable
    {
        int Output { get; }
    }
}
